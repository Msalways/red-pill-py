"""Redpill - AI-powered generic SDK for dynamic chart generation."""

__version__ = "0.1.0"

from redpill.client import Redpill

__all__ = ["Redpill", "__version__"]
