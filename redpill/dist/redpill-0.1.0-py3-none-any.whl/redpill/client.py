"""Main Redpill client for chart generation."""

import json
from typing import Any, AsyncIterator, Union

from langchain_core.language_models import BaseChatModel

from redpill.agents.intent_spec_agent import IntentSpecAgent
from redpill.agents.validator import ValidatorAgent, ValidationResult
from redpill.agents.langgraph_agent import LangGraphAgent
from redpill.config.builder import RedpillConfig, RedpillConfigBuilder
from redpill.executor.polars_executor import PolarsExecutor, AsyncPolarsExecutor
from redpill.processor.processor import DataProcessor
from redpill.providers import LLMProvider
from redpill.spec.schema import ChartSpec, ChartDataResult


class Redpill:
    """Main client for the Redpill SDK.

    Usage:
        # Initialize
        rp = (
            Redpill()
            .provider("openai")
            .api_key("sk-...")
            .build()
        )

        # Generate spec (one-time)
        result = rp.generate_spec(
            data=sample_data,
            prompt="show me tickets by status"
        )

        # Execute with stored spec
        chart_data = rp.execute(
            spec=result.spec,
            data=full_data
        )
    """

    def __init__(self, config: RedpillConfig | None = None) -> None:
        self._builder = RedpillConfigBuilder()
        self._config = config
        self._provider = None
        self._processor = None
        self._executor = None
        self._async_executor = None
        self._intent_spec_agent = None
        self._validator_agent = None
        self._langgraph_agent = None

    def provider(self, provider: str) -> "Redpill":
        """Set LLM provider."""
        self._builder.provider(provider)
        return self

    def api_key(self, api_key: str) -> "Redpill":
        """Set API key."""
        self._builder.api_key(api_key)
        return self

    def base_url(self, base_url: str) -> "Redpill":
        """Set custom base URL."""
        self._builder.base_url(base_url)
        return self

    def model(self, model: str) -> "Redpill":
        """Set model name."""
        self._builder.model(model)
        return self

    def temperature(self, temperature: float) -> "Redpill":
        """Set temperature."""
        self._builder.temperature(temperature)
        return self

    def max_tokens(self, max_tokens: int) -> "Redpill":
        """Set max tokens."""
        self._builder.max_tokens(max_tokens)
        return self

    def timeout(self, timeout: int) -> "Redpill":
        """Set timeout."""
        self._builder.timeout(timeout)
        return self

    def max_retries(self, max_retries: int) -> "Redpill":
        """Set max retries."""
        self._builder.max_retries(max_retries)
        return self

    def sample_size(self, sample_size: int) -> "Redpill":
        """Set sample size."""
        self._builder.sample_size(sample_size)
        return self

    def region(self, region: str) -> "Redpill":
        """Set AWS region for Bedrock provider."""
        self._builder.region(region)
        return self

    def credentials_profile_name(self, profile: str) -> "Redpill":
        """Set AWS credentials profile for Bedrock provider."""
        self._builder.credentials_profile_name(profile)
        return self

    def api_version(self, api_version: str) -> "Redpill":
        """Set API version for Azure OpenAI provider."""
        self._builder.api_version(api_version)
        return self

    def azure_deployment(self, deployment: str) -> "Redpill":
        """Set deployment name for Azure OpenAI provider."""
        self._builder.azure_deployment(deployment)
        return self

    def debug_mode(self, debug_mode: bool) -> "Redpill":
        """Enable or disable debug mode."""
        self._builder.debug_mode(debug_mode)
        return self

    def llm(self, llm: BaseChatModel) -> "Redpill":
        """Set a custom LangChain LLM instance.

        This allows you to pass your own configured LLM instead of using
        the built-in provider configuration. Useful when you already have
        your LLM configured in your application.

        Args:
            llm: A LangChain chat model instance

        Example:
            from langchain_openai import ChatOpenAI
            from redpill import Redpill

            llm = ChatOpenAI(api_key="sk-...", model="gpt-4o")
            rp = Redpill().llm(llm).build()

            # Or with Anthropic
            from langchain_anthropic import ChatAnthropic

            llm = ChatAnthropic(api_key="sk-ant-...", model="claude-3-sonnet-20240229")
            rp = Redpill().llm(llm).build()

            # Or with any LangChain-compatible model
            from langchain_ollama import ChatOllama

            llm = ChatOllama(model="llama3")
            rp = Redpill().llm(llm).build()
        """
        self._builder.llm(llm)
        return self

    def build(self) -> "Redpill":
        """Build and return the configured client."""
        self._config = self._builder.build()
        
        # If custom LLM is provided, wrap it with LLMProvider
        if self._config.llm is not None:
            self._provider = LLMProvider(
                llm=self._config.llm,
                temperature=self._config.temperature,
                max_tokens=self._config.max_tokens,
            )
        else:
            raise ValueError(
                "Please provide an LLM using .llm(llm). "
                "Example: Redpill().llm(ChatOpenAI(api_key='sk-...')).build()"
            )
        
        self._processor = DataProcessor()
        self._executor = PolarsExecutor()
        self._async_executor = AsyncPolarsExecutor()
        self._intent_spec_agent = IntentSpecAgent(self._provider, self._config)
        self._validator_agent = ValidatorAgent(self._provider, self._config)
        self._langgraph_agent = LangGraphAgent(
            self._provider, self._config, self._processor
        )
        return self

    def _ensure_initialized(self) -> None:
        """Ensure the client is initialized."""
        if self._provider is None:
            if self._config is None:
                self._config = self._builder.build()
            self.build()

    @classmethod
    def create(cls, **kwargs: Any) -> RedpillConfigBuilder:
        """Create a new configuration builder.

        Args:
            **kwargs: Initial configuration options

        Returns:
            RedpillConfigBuilder instance
        """
        builder = RedpillConfigBuilder()
        for key, value in kwargs.items():
            if hasattr(builder, key):
                getattr(builder, key)(value)
        return builder

    def generate_spec(
        self,
        data: Any,
        prompt: str,
    ) -> "GenerateSpecOutput":
        """Generate a chart specification from data and prompt.

        Args:
            data: Raw JSON data (dict, list, or JSON string)
            prompt: User's natural language prompt for chart

        Returns:
            GenerateSpecOutput with spec, profile, and params

        Example:
            result = rp.generate_spec(
                data={"tickets": [...]},
                prompt="show me tickets by status with priority breakdown"
            )
            stored_spec = result.spec
        """
        self._ensure_initialized()
        
        processed = self._processor.process(
            data, sample_size=self._config.sample_size
        )

        flat_data = processed["flat_data"]
        profile = processed["profile"]

        spec_result = self._intent_spec_agent.run(
            prompt=prompt,
            profile=profile,
            sample_data=flat_data,
        )

        spec = spec_result["spec"]
        params = spec_result["params"]

        validation_result = self._validator_agent.run(
            spec=spec,
            profile=profile,
        )

        if not validation_result.is_valid:
            raise ValueError(
                f"Spec validation failed: {validation_result.error}"
            )

        return GenerateSpecOutput(
            spec=spec,
            profile=profile,
            params=params,
        )

    def generate_spec_with_agent(
        self,
        data: Any,
        prompt: str,
    ) -> "GenerateSpecOutput":
        """Generate spec using LangGraph agent with automatic retry.

        Uses LangGraph workflow: process_data -> generate_spec -> validate_spec
        with automatic retry on validation failure.

        Args:
            data: Raw JSON data
            prompt: User's natural language prompt

        Returns:
            GenerateSpecOutput with spec, profile, params
        """
        self._ensure_initialized()

        result = self._langgraph_agent.run(data=data, prompt=prompt)

        return GenerateSpecOutput(
            spec=result["spec"],
            profile=result["profile"],
            params=result["params"],
        )

    def execute(
        self,
        spec: ChartSpec,
        data: Any,
    ) -> ChartDataResult:
        """Execute chart specification on data.

        Args:
            spec: Chart specification (from generate_spec)
            data: Full dataset (can be large)

        Returns:
            ChartDataResult with chart-ready data

        Example:
            chart_data = rp.execute(
                spec=stored_spec,
                data=full_dataset
            )
        """
        self._ensure_initialized()
        return self._executor.execute(spec, data)

    async def execute_stream(
        self,
        spec: ChartSpec,
        data: Any,
        batch_size: int = 10000,
    ) -> AsyncIterator[list[dict]]:
        """Execute spec on data in streaming batches.

        Args:
            spec: Chart specification
            data: Large dataset
            batch_size: Number of rows per batch

        Yields:
            Batches of chart-ready data
        """
        async for batch in self._async_executor.execute_stream(
            spec, data, batch_size
        ):
            yield batch

    def validate_spec(
        self,
        spec: ChartSpec,
        profile: dict[str, Any],
    ) -> ValidationResult:
        """Validate a chart spec against data profile.

        Args:
            spec: Chart specification to validate
            profile: Data profile

        Returns:
            ValidationResult
        """
        self._ensure_initialized()
        return self._validator_agent.run(spec=spec, profile=profile)


class GenerateSpecOutput:
    """Output from generate_spec method."""

    def __init__(
        self,
        spec: ChartSpec,
        profile: dict[str, Any],
        params: Any,
    ) -> None:
        self.spec = spec
        self.profile = profile
        self.params = params

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "spec": self.spec.model_dump(),
            "profile": self.profile,
            "params": self.params.model_dump() if self.params else {},
        }

    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
