"""Configuration builder for Redpill SDK."""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Union

import httpx

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel


@dataclass
class RedpillConfig:
    """Configuration for Redpill SDK."""

    provider: str = "openai"
    api_key: str | None = None
    base_url: str | None = None
    model: str = "gpt-4o"
    temperature: float = 0.7
    max_tokens: int = 4000
    timeout: int = 60
    max_retries: int = 3
    sample_size: int = 100
    region: str | None = None
    credentials_profile_name: str | None = None
    api_version: str | None = None
    azure_deployment: str | None = None
    debug_mode: bool = False
    llm: "BaseChatModel | None" = None


class RedpillConfigBuilder:
    """Fluent builder for Redpill configuration."""

    def __init__(self) -> None:
        self._config = RedpillConfig()

    def provider(self, provider: str) -> "RedpillConfigBuilder":
        """Set LLM provider (openai, anthropic)."""
        self._config.provider = provider
        return self

    def api_key(self, api_key: str) -> "RedpillConfigBuilder":
        """Set API key for the provider."""
        self._config.api_key = api_key
        return self

    def base_url(self, base_url: str) -> "RedpillConfigBuilder":
        """Set custom base URL (for OpenAI-compatible APIs)."""
        self._config.base_url = base_url
        return self

    def model(self, model: str) -> "RedpillConfigBuilder":
        """Set model name."""
        self._config.model = model
        return self

    def temperature(self, temperature: float) -> "RedpillConfigBuilder":
        """Set temperature for LLM generation."""
        self._config.temperature = temperature
        return self

    def max_tokens(self, max_tokens: int) -> "RedpillConfigBuilder":
        """Set max tokens for LLM generation."""
        self._config.max_tokens = max_tokens
        return self

    def timeout(self, timeout: int) -> "RedpillConfigBuilder":
        """Set request timeout in seconds."""
        self._config.timeout = timeout
        return self

    def max_retries(self, max_retries: int) -> "RedpillConfigBuilder":
        """Set max retries for failed requests."""
        self._config.max_retries = max_retries
        return self

    def sample_size(self, sample_size: int) -> "RedpillConfigBuilder":
        """Set number of rows to sample for LLM analysis."""
        self._config.sample_size = sample_size
        return self

    def region(self, region: str) -> "RedpillConfigBuilder":
        """Set AWS region for Bedrock provider."""
        self._config.region = region
        return self

    def credentials_profile_name(self, profile: str) -> "RedpillConfigBuilder":
        """Set AWS credentials profile for Bedrock provider."""
        self._config.credentials_profile_name = profile
        return self

    def api_version(self, api_version: str) -> "RedpillConfigBuilder":
        """Set API version for Azure OpenAI provider."""
        self._config.api_version = api_version
        return self

    def azure_deployment(self, deployment: str) -> "RedpillConfigBuilder":
        """Set deployment name for Azure OpenAI provider."""
        self._config.azure_deployment = deployment
        return self

    def debug_mode(self, debug_mode: bool) -> "RedpillConfigBuilder":
        """Enable or disable debug mode."""
        self._config.debug_mode = debug_mode
        return self

    def llm(self, llm: "BaseChatModel") -> "RedpillConfigBuilder":
        """Set a custom LangChain LLM instance.

        This allows you to pass your own configured LLM instead of using
        the built-in provider configuration.

        Args:
            llm: A LangChain chat model instance (e.g., ChatOpenAI, ChatAnthropic)

        Example:
            from langchain_openai import ChatOpenAI

            llm = ChatOpenAI(api_key="sk-...", model="gpt-4o")
            rp = Redpill().llm(llm).build()
        """
        self._config.llm = llm
        return self

    def build(self) -> RedpillConfig:
        """Build the configuration."""
        return self._config


def create_client(**kwargs: Any) -> RedpillConfigBuilder:
    """Create a new Redpill configuration builder."""
    builder = RedpillConfigBuilder()
    for key, value in kwargs.items():
        if hasattr(builder, key):
            getattr(builder, key)(value)
    return builder
