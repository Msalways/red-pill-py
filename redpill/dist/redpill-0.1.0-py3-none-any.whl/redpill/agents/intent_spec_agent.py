"""Intent Parser + Spec Generator agent."""

import json
import sys
from typing import Any

from redpill.agents.base import BaseAgent
from redpill.config.builder import RedpillConfig
from redpill.prompts.intent_spec import (
    INTENT_SPEC_SYSTEM_PROMPT,
    build_intent_spec_prompt,
)
from redpill.providers import LLMProvider
from redpill.spec.schema import ChartSpec, RuntimeParams


class IntentSpecAgent(BaseAgent):
    """Agent that parses user intent and generates chart specification."""

    def __init__(self, provider: LLMProvider, config: RedpillConfig) -> None:
        super().__init__(provider, config)

    def run(
        self,
        prompt: str,
        profile: dict[str, Any],
        sample_data: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Generate chart spec from prompt and data profile.

        Args:
            prompt: User's natural language prompt
            profile: Data profile from processor
            sample_data: Sample flattened data

        Returns:
            Dictionary with 'spec' (ChartSpec) and 'params' (RuntimeParams)
        """
        user_prompt = build_intent_spec_prompt(
            prompt=prompt,
            profile=profile,
            sample_data=sample_data,
            sample_size=self.config.sample_size,
        )

        for attempt in range(self.max_retries):
            try:
                response = self.provider.generate(
                    prompt=user_prompt,
                    system_prompt=INTENT_SPEC_SYSTEM_PROMPT,
                    temperature=self.config.temperature,
                    max_tokens=self.config.max_tokens,
                )

                print(f"[DEBUG] Raw LLM response: {response[:500]}...", file=sys.stderr)
                
                result = self._parse_json_response(response)

                spec_dict = result.get("spec", result)
                params_dict = result.get("params", {})

                spec_dict["params"] = params_dict

                spec = ChartSpec(**spec_dict)
                params = RuntimeParams(**params_dict)

                return {
                    "spec": spec,
                    "params": params,
                }

            except Exception as e:
                if attempt == self.max_retries - 1:
                    raise RuntimeError(
                        f"Failed to generate spec after {self.max_retries} attempts: {e}"
                    ) from e
                continue

        raise RuntimeError("Failed to generate spec: max retries exceeded")
